module.exports = class User {
    constructor(socketId, pseudo, channel) {
        this.id = socketId;
        this.pseudo = pseudo;
        this.channel = channel;
        this.isTyping= false;
    }
}
